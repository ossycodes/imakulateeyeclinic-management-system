	
$(function () {

  'use strict';
	  
		/* BOOTSTRAP SLIDER */
		$('.slider').slider()


}); // End of use strict
