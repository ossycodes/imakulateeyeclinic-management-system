<?php

namespace App\Providers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);
        
        //comment the rest of the line to make test pass
        //share notificationCount with all views
        $notificationCount = DB::table('notifications')
            ->whereNull('read_at')
            ->count();
        // View::share('notificationCount', $notificationCount);
        View::composer('*', function ($view) use ($notificationCount) {
            $view->with('notificationCount', $notificationCount);
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
