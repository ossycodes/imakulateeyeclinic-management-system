<header class="main-header">
<!-- Logo -->
<a href="#" class="logo">
    <!-- mini logo -->
    <h6 class="logo-mini">
        
        <p>IMAKULATEEYECLINIC</p>
    </h6>
    <!-- logo-->
    
    <h6 class="logo-lg">
        
        
    </h6>
</a>
<!-- Header Navbar -->
<nav class="navbar navbar-static-top">
    <!-- Sidebar toggle button-->
    <a href="data.html#" class="sidebar-toggle" data-toggle="push-menu" role="button">
    <span class="sr-only">Toggle navigation</span>
    </a>

    <div class="navbar-custom-menu">
    <ul class="nav navbar-nav">
        <!-- Notifications -->
        <li class="dropdown notifications-menu">
        <a href="data.html#" class="dropdown-toggle" data-toggle="dropdown">
            <i class="mdi mdi-bell"></i>
        </a>
        <ul class="dropdown-menu scale-up">
            <?php if(auth()->user()->unreadNotifications): ?>    
                <li class="header">You have <?php $count = count(auth()->user()->unreadNotifications);  echo $count; ?> <?php echo e(str_plural('notification', $count)); ?></li>
                <li>
            <?php endif; ?>
                <!-- inner menu: contains the actual data -->
            <?php if($notificationCount): ?>
            <ul class="menu inner-content-div">
                    <?php $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><a href="<?php echo e(route('celebrants')); ?>"><b><?php echo e($notification->data['patients_fullname']); ?> have birthday today!</b></a></p>
                            
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
            </li>
            <?php if($notificationCount): ?>
                <li class="footer"><a href="<?php echo e(route('notification.markasread')); ?>">Mark as read</a></li>
            <?php endif; ?>
        </ul>
        </li>

        <!-- User Account-->
        <li class="dropdown user user-menu">
        <a href="data.html#" class="dropdown-toggle" data-toggle="dropdown">
            <i class="fa fa-user-circle"></i>
        </a>
        <ul class="dropdown-menu scale-up">
            <!-- User image -->
            <li class="user-body">
            
            <?php if(auth()->check()): ?>
                <p>
                    <?php echo e(auth()->user()->name); ?>

                    <small class="mb-5"><?php echo e(auth()->user()->email); ?></small>
                </p>
             <?php endif; ?>
            </li>
            <!-- Menu Body -->
            <li class="user-body">
            <div class="row no-gutters">
                
                
            <div role="separator" class="divider col-12"></div>
                <div class="col-12 text-left">
                <a href="<?php echo e(route('changepassword')); ?>"><i class="ti-settings"></i> Change Password</a>
                </div>
            <div role="separator" class="divider col-12"></div>
                <div class="col-12 text-left">
                  <a href="<?php echo e(route('logout')); ?>"><i class="fa fa-power-off"></i> Logout</a>
                </div>				
            </div>
            <!-- /.row -->
            </li>
        </ul>
        </li>
        <!-- Control Sidebar Toggle Button -->
        <li>
        <a href="data.html#" data-toggle="control-sidebar"><i class="fa fa-cog fa-spin"></i></a>
        </li>
    </ul>
    </div>
</nav>
</header>