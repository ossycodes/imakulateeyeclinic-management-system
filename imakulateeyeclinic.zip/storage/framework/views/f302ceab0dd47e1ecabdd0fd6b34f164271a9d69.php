<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startPush('stylesheet'); ?>
        <!--alerts CSS -->
        <link href="<?php echo e(asset('assets/vendor_components/sweetalert/sweetalert.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopPush(); ?>

    <!-- Main content -->
    <section class="content">
     
    
     <!-- Basic Forms -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Edit Patient Details</h3>
          <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashbaord')); ?>"><i class="fa fa-dashboard"></i>dashboard</a></li>
                <li class="breadcrumb-item active"><a href="<?php echo e(route('patients.index')); ?>">patients</a></li>
                <li class="breadcrumb-item active">Registered</li>
          </ol>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="row">
            <div class="col">
            	<form method="POST" action="<?php echo e(route('patient.update', ['patient' => $patient])); ?>" novalidate id="form"><?php echo csrf_field(); ?>
                   <?php echo method_field('PATCH'); ?>
                   <input type="hidden" value="<?php echo e($patient->id); ?>" id="patientId">
                   
                   <div class="form-group">
                        <h5>Clinic card number: <span class="text-danger">*</span></h5>
                        <div class="controls">
                            <input type="text" id="wcliniccardnumber" value="<?php echo e($patient->cliniccardnumber); ?>" name="cliniccardnumber" class="form-control" required data-validation-required-message="This field is required"> 
                        </div>
                    </div>
					<div class="form-group">
						<h5>Full Name: <span class="text-danger">*</span></h5>
						<div class="controls">
                            <input type="text" id="wfullname" value="<?php echo e($patient->fullname); ?>" name="fullname" class="form-control" required data-validation-required-message="This field is required"> 
                        </div>
                    </div>
                    <div class="form-group">
						<h5>Parent's Name: <span class="text-danger">*</span></h5>
						<div class="controls">
                            <input type="text" id="wparentname" value="<?php echo e($patient->parentname); ?>" name="parentname" class="form-control" required data-validation-required-message="This field is required"> 
                        </div>
					</div>
					<div class="form-group">
						<h5>Address: <span class="text-danger">*</span></h5>
						<div class="controls">
                            <input type="text" id="waddress" value="<?php echo e($patient->address); ?>" name="address" class="form-control" required data-validation-required-message="This field is required"> 
                        </div>
                    </div>
                    <div class="form-group">
						<h5>Occupation: <span class="text-danger">*</span></h5>
						<div class="controls">
                            <input type="text" id="woccupation" value="<?php echo e($patient->occupation); ?>" name="occupation" class="form-control" required data-validation-required-message="This field is required"> 
                        </div>
                    </div>
                    <div class="form-group">
                            <h5>Phonenumber: <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="number" id="wphonenumber" value="<?php echo e($patient->phonenumber); ?>" name="phonenumber" class="form-control" required data-validation-required-message="This field is required"> 
                            </div>
                    </div>
                    <div class="form-group">
                            <h5>Alternative Phonenumber: </h5>
                            <div class="controls">
                                <input type="number" id="walternatephonenumber" value="<?php echo e($patient->alternativephonenumber); ?>" name="alternativephonenumber" class="form-control"> 
                            </div>
                    </div>
                    <div class="form-group">
                        <h5>Next Of Kin: <span class="text-danger">*</span></h5>
                        <div class="controls">
                            <input type="text" id="wnextofkin" value="<?php echo e($patient->nextofkin); ?>" name="nextofkin" class="form-control" required data-validation-required-message="This field is required"> 
                        </div>
                    </div>

                    <div class="form-group">
                        <h5>Date Of Birth: <span class="text-danger">*</span></h5>
                        <div class="controls">
                            <input type="date" id="wdateofbirth" value="<?php echo e($patient->dateofbirth); ?>" name="dateofbirth" class="form-control" required data-validation-required-message="This field is required"> </div>
                        <div class="form-control-feedback">This field is required</div>
                    </div>

					<div class="text-xs-right">
						<input type="submit" class="btn btn-info" value="update"/>
					</div>
				</form>
            	
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->

    <?php $__env->startPush('scripts'); ?>
        <!-- Form validator JavaScript -->
        <script src="<?php echo e(asset('js/pages/validation.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor_components/sweetalert/sweetalert.min.js')); ?>"></script>
        <script>
        ! function(window, document, $) {
            "use strict";
                $("input,select,textarea").not("[type=submit]").jqBootstrapValidation();
            }(window, document, jQuery);
        </script>
       
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

  
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>