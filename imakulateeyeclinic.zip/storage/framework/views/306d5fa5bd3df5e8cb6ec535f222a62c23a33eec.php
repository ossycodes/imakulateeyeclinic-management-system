  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
        <!-- sidebar-->
        <section class="sidebar">
          
          <!-- sidebar menu-->
          <ul class="sidebar-menu" data-widget="tree">
            <li>
              <a href="<?php echo e(route('dashbaord')); ?>">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
              </a>
            </li>
            
            <li class="treeview">
              <a href="data.html#">
                <i class="fa fa-th"></i>
                <span>Patients</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-right pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(route('patients.create')); ?>"><i class="fa fa-circle-thin"></i>Register</a></li>
                <li><a href="<?php echo e(route('patients.index')); ?>"><i class="fa fa-circle-thin"></i>Registered Patients</a></li>
                <li><a href="<?php echo e(route('celebrants')); ?>"><i class="fa fa-circle-thin"></i>Celebrants</a></li>
                <li><a href="<?php echo e(route('casefile')); ?>"><i class="fa fa-circle-thin"></i>Case File</a></li>
                <li><a href="<?php echo e(route('relatedfiles')); ?>"><i class="fa fa-circle-thin"></i>Related Files</a></li>
                
              </ul>
            </li>
          </ul>
        </section>
      </aside>