<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startPush('stylesheet'); ?>
        <!--alerts CSS -->
        <link href="<?php echo e(asset('assets/vendor_components/sweetalert/sweetalert.css')); ?>" rel="stylesheet" type="text/css">
    <?php $__env->stopPush(); ?>
    
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Case File For <?php echo e($patient->fullname); ?>

          </h1>
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="form-validation.html#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="breadcrumb-item"><a href="form-validation.html#">casefile</a></li>
            <li class="breadcrumb-item active">edit</li>
          </ol>
        </section>
    
        <!-- Main content -->
        <section class="content">
         
         <!-- Basic Forms -->
          <div class="box">
            <div class="box-header with-border">
              
              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">

                <div class="col">
                            <input type="hidden" name="patient_id" value="<?php echo e($patient->id); ?>">
                            
                                    <h5>Case History <span class="text-danger">*</span></h5>
                                    <div class="box">
                                        <!-- /.box-header -->
                                        <div class="box-body" >
                                            <textarea class="textarea" id="editor1" name="casehistory"  placeholder="Place some text here"
                                                    style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" disabled required>
                                                    <?php echo e($casefile->casehistory); ?>

                                            </textarea>
                                        </div>
                                    </div>
                                    <!-- /.box -->
                                
                                    
                                
                                    <h5>Systemic <span class="text-danger">*</span></h5>
                                    <div class="box">
                                        <!-- /.box-header -->
                                        <div class="box-body">
                                            <textarea class="textarea" id="editor2" name="systemic"  placeholder="Place some text here"
                                                    style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" disabled required>
                                                    <?php echo e($casefile->systemic); ?>

                                            </textarea>
                                        </div>
                                    </div>
                                <!-- /.box -->
                                

                        <div class="form-group">
                            <h5>Family (Oculo-visual ) <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->family); ?>" name="family" class="form-control" > </div>
                            
                        </div>

                        <div class="form-group">
                            <h5>Last Eye Examinxation <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->lasteyeexamination); ?>" name="lasteyeexamination" class="form-control" > </div>
                            
                        </div>

                        <div class="form-group">
                            <label>UNAIDED VISUAL ACUITY @6M  </label>
                            <br>
                            <label>O.D</label>
                            <div class="controls">
                                <input type="text" <?php echo e($casefile->uvaod6m); ?> name="uvaod6m" class="form-control" disabled> </div>
                            
                            <br>
                            <label>O.S</label>
                            <div class="controls">
                                <input type="text" <?php echo e($casefile->uvaos6m); ?> name="uvaos6m" class="form-control" disabled> </div>
                            
                        </div>

                        <div class="form-group">
                            <label>UNAIDED VISUAL ACUITY @0.4M </label>
                            <br>
                            <label>O.D</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->uvaod04m); ?>" name="uvaod04m" class="form-control" > </div>
                            
                            <br>
                            <label>O.S</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->uvaos04m); ?>" name="uvaos04m" class="form-control" > </div>
                            
                        </div>      

                        <div class="form-group">
                            <label> PINHOLE TEST </label>
                            <br>
                            <label>O.D</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->pinhholetestod); ?>"  name="pinhholetestod" class="form-control" > </div>
                            
                            <br>
                            <label>O.S</label>
                            <div class="controls">
                                <input type="text"  disabled value="<?php echo e($casefile->pinholetestos); ?>" name="pinholetestos" class="form-control" > </div>
                            
                        </div>  

                        <div class="form-group">
                            <label> STENOPAIC DISC </label>
                            <br>
                            <label>O.D</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->stenopaicdiscod); ?>" name="stenopaicdiscod" class="form-control" > </div>
                            
                            <br>
                            <label>O.S</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->stenopaicdiscos); ?>" name="stenopaicdiscos" class="form-control" > </div>
                            
                        </div> 
                        
                        <div class="form-group">
                            <label>AIDED VISUAL ACUITY @6M  </label>
                            <br>
                            <label>O.D</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->avaod6m); ?>" name="avaod6m" class="form-control" > </div>
                            
                            <br>
                            <label>O.S</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->avaos6m); ?>" name="avaos6m" class="form-control" > </div>
                            
                        </div>  

                        <div class="form-group">
                            <label>AIDED VISUAL ACUITY @0.4M </label>
                            <br>
                            <label>O.D</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->avaod04m); ?>" name="avaod04m" class="form-control" > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                            <br>
                            <label>O.S</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->avaos04m); ?>" name="avaos04m" class="form-control" > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                        </div>  

                        <div class="form-group">
                            <label>PRESENT PRESCRIPTION</label>
                            <br>
                            <label>O.D</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->ppod); ?>"  name="ppod" class="form-control" > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                            <br>
                            <label>O.S</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->ppos); ?>" name="ppos" class="form-control" > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                        </div>

                        <h5>EXTERNAL EXAMINATION <span class="text-danger">*</span></h5>
                        <div class="box">
                            <!-- /.box-header -->
                            <div class="box-body">
                                <textarea class="textarea" id="editor15" name="ee"  placeholder="Place some text here"
                                        style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" disabled required>
                                        <?php echo e($casefile->ee); ?>

                                </textarea>
                            </div>
                        </div>

                        <h5>UNAIDED VISUAL ACUITY @6M  <span class="text-danger">*</span></h5>
                        <div class="box">
                            <!-- /.box-header -->
                            <div class="box-body">
                                <textarea class="textarea" id="editor16" name="uva6m"  placeholder="Place some text here"
                                        style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" disabled required>
                                        <?php echo e($casefile->uva6m); ?>

                                </textarea>
                            </div>
                        </div>

                        <h5>UNAIDED EXAMINATION <span class="text-danger">*</span></h5>
                        <div class="box">
                            <!-- /.box-header -->
                            <div class="box-body">
                                <textarea class="textarea" id="editor17" name="ue"  placeholder="Place some text here"
                                        style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" disabled required>
                                        <?php echo e($casefile->ue); ?>

                                </textarea>
                            </div>
                        </div>

                        <h5>INTERNAL EXAMINATION <span class="text-danger">*</span></h5>
                        <div class="box">
                            <!-- /.box-header -->
                            <div class="box-body">
                                <textarea class="textarea" id="editor18" name="ie"  placeholder="Place some text here"
                                        style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" disabled required>
                                        <?php echo e($casefile->ie); ?>

                                </textarea>
                            </div>
                        </div>


                        <div class="form-group">
                            <h5>Preferred eye<span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="text" name="prefferedeye" disabled value="<?php echo e($casefile->prefferedeye); ?>" class="form-control" > </div>
                            
                        </div>

                        <div class="form-group">
                            <h5>Blood Pressure <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="text"  disabled value="<?php echo e($casefile->bloodpressure); ?>" name="bloodpressure" class="form-control" > </div>
                            
                        </div>

                        <div class="form-group">
                            <h5>Blood Sugar <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->bloodsugar); ?>" name="bloodsugar" class="form-control" > </div>
                            
                        </div>

                        <div class="form-group">
                            <h5> Weight <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->weight); ?>" name="weight" class="form-control" > </div>
                            
                        </div>

                        <div class="form-group">
                            <h5> Age <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->age); ?>" name="age" class="form-control" > </div>
                            
                        </div>

                        <div class="form-group">
                            <label>TONOMETRY</label>
                            <br>
                            <label>O.D</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->tonometryod); ?>"  name="tonometryod" class="form-control" > </div>
                            
                            <br>
                            <label>O.S</label>
                            <div class="controls">
                                <input type="text" name="tonometryos" disabled value="<?php echo e($casefile->tonometryos); ?>" class="form-control" > </div>
                            
                        </div>

                        <div class="form-group">
                            <h5> Time <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="text"  disabled value="<?php echo e($casefile->time); ?>" name="time" class="form-control" > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                        </div>

                        <div class="form-group">
                            <h5> Anaesthetics <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="text"  disabled value="<?php echo e($casefile->anaesthetics); ?>" name="anaesthetics" class="form-control" > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                        </div>

                        <div class="form-group">
                            <label>AUTOREFRACTOMETRY</label>
                            <br>
                            <label>O.D</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->autorefractometryod); ?>" name="autorefractometryod" class="form-control" > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                            <br>
                            <label>O.S</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->autorefractometryos); ?>" name="autorefractometryos" class="form-control" > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                        </div>      
                        
                        <div class="form-group">
                            <label>STATIC RETINOSCOPY</label>
                            <br>
                            <label>O.D</label>
                            <div class="controls">
                                <input type="text"  disabled value="<?php echo e($casefile->staticretinoscopyod); ?>"  name="staticretinoscopyod" class="form-control" > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                            <br>
                            <label>O.S</label>
                            <div class="controls">
                                <input type="text"  disabled value="<?php echo e($casefile->staticretinoscopyos); ?>" name="staticretinoscopyos" class="form-control" > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                        </div>

                        <div class="form-group">
                            <h5> SUBJECTIVE <span class="text-danger">*</span></h5>
                            <label>O.D</label>
                            <div class="controls">
                                <input type="text"  disabled value="<?php echo e($casefile->subjectiveod); ?>" name="subjectiveod" class="form-control"  > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                            <br>
                            <label>O.S</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->subjectiveos); ?>" name="subjectiveos" class="form-control"  > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                            <br>
                            <label>ADD</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->staticretinoscopyadd); ?>" name="staticretinoscopyadd" class="form-control"  > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                        </div>

                        <div class="form-group">
                            <label>SPECTACLE PRESCRIPTION</label>
                            <br>
                            <label>O.D</label>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->spectacleprescriptionod); ?>" name="spectacleprescriptionod" class="form-control" > </div>
                            
                            <br>
                            <label>O.S</label>
                            <div class="controls">
                                <input type="text"  disabled value="<?php echo e($casefile->spectacleprescriptionos); ?>" name="spectacleprescriptionos" class="form-control" > </div>
                            
                        </div>

                        
                        <div class="form-group">
                            <h5> P D  <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="text" disabled value="<?php echo e($casefile->pd); ?>" name="pd" class="form-control" > </div>
                            
                        </div>

                        <div class="form-group">
                            <h5>Recommendation<span class="text-danger">*</span></h5>
                            <div class="controls">

                                <fieldset>
                                    <input type="checkbox" id="checkbox_1" name="dist" disabled value="dist" <?php echo e($casefile->dist ? 'checked' : ''); ?>>
                                    <label for="checkbox_1">Dist</label>
                                </fieldset>
                                <fieldset>
                                    <input type="checkbox" id="checkbox_2" name="near" disabled value="near" <?php echo e($casefile->near ? 'checked' : ''); ?>>
                                    <label for="checkbox_2">Near</label>
                                </fieldset>
                                <fieldset>
                                    <input type="checkbox" id="checkbox_3" name="bifocal" disabled value="bifocal" <?php echo e($casefile->bifocal ? 'checked' : ''); ?>>
                                    <label for="checkbox_3">Bifocal</label>
                                </fieldset>
                                <fieldset>
                                    <input type="checkbox" id="checkbox_4" name="vanilux" disabled value="vanilux" <?php echo e($casefile->vanilux ? 'checked' : ''); ?>>
                                    <label for="checkbox_4">Vanilux</label>
                                </fieldset>
                                <fieldset>
                                    <input type="checkbox" id="checkbox_5" name="typesoflenses" disabled value="typesoflenses" <?php echo e($casefile->typesoflenses ? 'checked' : ''); ?>>
                                    <label for="checkbox_5">Types of lens</label>
                                </fieldset>
                                <fieldset>
                                    <input type="checkbox" id="checkbox_6" name="thinnerlenses" disabled value="thinnerlenses" <?php echo e($casefile->thinnerlenses ? 'checked' : ''); ?>>
                                    <label for="checkbox_6">Thinner lenses</label>
                                </fieldset>
                                <fieldset>
                                    <input type="checkbox" id="checkbox_7" name="antireflectivelenses" disabled value="antireflectivelenses" <?php echo e($casefile->antireflectivelenses ? 'checked' : ''); ?>>
                                    <label for="checkbox_7">Anti-reflective lenses</label>
                                </fieldset>
                                <fieldset>
                                    <input type="checkbox" id="checkbox_8" name="photochronic" disabled value="photochronic" <?php echo e($casefile->photochronic ? 'checked' : ''); ?>>
                                    <label for="checkbox_8">Photochronic</label>
                                </fieldset>
                                <fieldset>
                                    <input type="checkbox" id="checkbox_9" name="sunglasses" disabled value="sunglasses" <?php echo e($casefile->sunglasses ? 'checked' : ''); ?>>
                                    <label for="checkbox_9">Sunglases</label>
                                </fieldset>
                              
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <h5> Tint <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="text" value="<?php echo e($casefile->tint); ?>"  disabled name="tint" class="form-control" > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                        </div>

                        <div class="form-group">
                            <h5> Next Appointment <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="text" value="<?php echo e($casefile->nextappointment); ?>" disabled name="nextappointment" class="form-control" > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                        </div>

                        <h5>ADDITIONAL TESTS, COMMENTS <span class="text-danger">*</span></h5>
                        <div class="box">
                            <!-- /.box-header -->
                            <div class="box-body">
                                <textarea class="textarea" id="editor20" name="additionaltestsandcomments"  placeholder="Place some text here" disabled
                                        style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" required>
                                        <?php echo e($casefile->additionaltestsandcomments); ?>

                                </textarea>
                            </div>
                        </div>

                        <h5 >ASSESSMENT PLAN <span class="text-danger">*</span></h5>
                        <div class="box">
                            <!-- /.box-header -->
                            <div class="box-body">
                                <textarea class="textarea" id="editor21" name="assessmentplan"  placeholder="Place some text here" 
                                        style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" disabled required>
                                        <?php echo e($casefile->assessmentplan); ?>

                                </textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <h5> DOCTOR'S NAME <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="text"  value="<?php echo e($casefile->doctorsname); ?>"  name="doctorsname" disabled class="form-control" > </div>
                            <div class="form-control-feedback"><small>Add <code>required</code> attribute to field for required validation.</small></div>
                        </div>

                        <div class="text-xs-right">
                            <a href="<?php echo e(route('casefile.edit', ['casefile' => $casefile, 'patient' => $patient])); ?>"><button class="btn btn-info">EDIT</button></a>
                        </div>
                    
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
          
        </section>
        <!-- /.content -->
  
  <?php $__env->startPush('scripts'); ?>
  
   <script>
       ! function(window, document, $) {
        "use strict";
            $("input,select,textarea").not("[type=submit]").jqBootstrapValidation();
        }(window, document, jQuery);
    </script>
 
  <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>