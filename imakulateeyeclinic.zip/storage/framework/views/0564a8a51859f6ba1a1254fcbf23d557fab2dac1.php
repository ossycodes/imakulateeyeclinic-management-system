<?php $__env->startSection('title', 'Registered Patients'); ?>


<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        File Description
    </h1>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="general.html#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('relatedfiles')); ?>">Related file</a></li>
        <li class="breadcrumb-item active">description</li>
    </ol>
</section>

<!-- Main content -->
<section class="content">

        <div class="row">

          <!--Multi elements!-->
          <?php $__empty_1 = true; $__currentLoopData = $relatedfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="col-12">
                <div class="box">
                  <div class="box-header with-border">
                    <h4 class="box-title">Created  - <?php echo e($file->created_at->diffForHumans()); ?> </h4>
                      <div class="box-controls pull-right">
                        <div class="box-header-actions">
                                <a href="<?php echo e(route('relatedfile.edit', ['relatedfile' => $file->id])); ?>"class="btn btn-app bg-blue">
                                        <i class="fa fa-edit"></i> Edit
                                    </a>
                          <form action="<?php echo e(route('relatedfile.destroy', ['relatedfile' => $file->id])); ?>" method="POST"><?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-app bg-green">  <i class="fa fa-stop"></i> Delete </button>
                         </form>
                        </div>
                      </div>
                  </div>
    
                  <div class="box-body">
                        <?php echo $file->record; ?>

                  </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                    <h1>
                        No FIle records for this patient
                    </h1>
            <?php endif; ?>      
  
        </div>
        
            <?php echo e($relatedfiles->render()); ?>

        
            <!-- /.row -->
        <!-- END TYPOGRAPHY -->
  
      </section>
      <!-- /.content -->

<?php $__env->stopSection(); ?>      
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>