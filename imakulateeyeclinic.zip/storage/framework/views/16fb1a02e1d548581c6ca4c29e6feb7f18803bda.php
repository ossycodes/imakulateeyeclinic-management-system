<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startPush('stylesheet'); ?>
        <!--alerts CSS -->
        <link href="<?php echo e(asset('assets/vendor_components/sweetalert/sweetalert.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopPush(); ?>

    <!-- Main content -->
    <section class="content">
    
     <!-- Basic Forms -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Change Password</h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <?php echo $__env->make('layouts.flashmessages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="row">
            <div class="col">
            	<form method="POST" action="<?php echo e(route('password.update')); ?>" novalidate id="form"><?php echo csrf_field(); ?>
                   <?php echo method_field('PATCH'); ?>
                   <div class="form-group">
						<h5>Old Password <span class="text-danger">*</span></h5>
						<div class="controls">
							<input type="password" name="oldPassword" class="form-control" required data-validation-required-message="This field is required"> </div>
                    </div>
                    <div class="form-group">
                            <h5>New Password <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="password" name="newPassword" class="form-control" required data-validation-required-message="This field is required"> </div>
                        </div>
					<div class="form-group">
						<h5>Repeat New Password <span class="text-danger">*</span></h5>
						<div class="controls">
							<input type="password" name="password2" data-validation-match-match="newPassword" class="form-control" required> </div>
					</div>
					<div class="text-xs-right">
						<input type="submit" class="btn btn-info" value="update"/>
					</div>
				</form>
            	
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
      
    </section>
    <!-- /.content -->

    <?php $__env->startPush('scripts'); ?>
        <!-- Form validator JavaScript -->
        <script src="<?php echo e(asset('js/pages/validation.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor_components/sweetalert/sweetalert.min.js')); ?>"></script>
        <script>
        ! function(window, document, $) {
            "use strict";
                $("input,select,textarea").not("[type=submit]").jqBootstrapValidation();
            }(window, document, jQuery);
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

  
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>