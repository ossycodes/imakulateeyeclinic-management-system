<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
      </h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Dashboard </a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
		<?php echo $__env->make('layouts.flashmessages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	  <div class="row">
        <div class="col-12 ">
		  <div class="row">

			<div class="col-sm-6 col-lg-3">
			  <div class="box pull-up">
				  <div class="box-body">
					<div class="flexbox mb-1">
					  <div>
						<p class="text-success font-size-26 font-weight-300 mb-0"><?php echo e($patientCount); ?></p>
						<?php echo e(str_plural('Patient', $patientCount)); ?>

					  </div>
					  <div class="text-success font-size-40"><i class="mdi mdi-account"></i></div>
					</div>
					<div class="progress progress-xxs mt-10 mb-0">
					  
					</div>
				  </div>
			  </div>
			</div>


			<div class="col-sm-6 col-lg-3">
			  <div class="box pull-up">
				  <div class="box-body">
					<div class="flexbox mb-1">
					  <div>
						<p class="text-danger font-size-26 font-weight-300 mb-0"><a href="<?php echo e(route('celebrants')); ?>"><?php echo e($celebrantCount); ?></a></p>
						<a href="<?php echo e(route('celebrants')); ?>"><?php echo e(str_plural('Patient', $celebrantCount)); ?> Have Birthday Today</a>
					  </div>
					  <div class="text-danger font-size-40"><i class="mdi mdi-cake"></i></div>
					</div>
					<div class="progress progress-xxs mt-10 mb-0">
					  
					</div>
				  </div>
			  </div>
			</div>
			
			<div class="col-md-6 col-lg-3 col-xlg-3">
				<div class="box box-inverse box-info pull-up">
					<div class="box-body text-center">
						<h1 class="font-light text-white"><?php echo e($casefilesCount); ?></h1>
						<h6 class="text-white mb-10"> Total Case Files </h6>
					</div>
				</div>
			</div>

			<div class="col-md-6 col-lg-3 col-xlg-3">
				<div class="box box-success box-inverse pull-up">
					<div class="box-body text-center">
						<h1 class="font-light text-white"><?php echo e($relatedfilesCount); ?></h1>
						<h6 class="text-white mb-10">Total  Related Files </h6>
					</div>
				</div>
			</div>
            
		  </div>
        </div>
        <!-- /.col -->		  
      </div>

    </section>
    <!-- /.content -->
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>