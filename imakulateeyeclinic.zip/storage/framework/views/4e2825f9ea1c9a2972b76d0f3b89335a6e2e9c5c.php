<?php $__env->startSection('title', 'Registered Patients'); ?>


<?php $__env->startSection('content'); ?>

	<?php $__env->startPush('stylesheet'); ?>

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.19/css/dataTables.bootstrap.css">

	<?php $__env->stopPush(); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        View and Create Additional Files For Patients
      </h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="data.html#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="breadcrumb-item"><a href="data.html#">Patients</a></li>
        <li class="breadcrumb-item active">view/create files</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
		<!-- Flash Session Message -->
		<?php echo $__env->make('layouts.flashmessages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="row">
        <div class="col-12">
         
         <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Patients Record Files</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
				<div class="table-responsive">
				  <table id="example1" class="table table-bordered table-striped">
					<thead>
						<tr>
							<th>Clinic Card Number</th>
							<th>Patient Full Name</th>
                            <th>Create File</th>
                            <th>View Files</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($patient->cliniccardnumber); ?></td>
							<td><?php echo e($patient->fullname); ?></td>
							<td>
							    <a href="<?php echo e(route('relatedfile.create', ['patient' => $patient])); ?>"><button type="button" class="btn btn-primary"><i class="fa fa-envelope"></i> Create File </button></a>
							</td>
                            <td>
                                <a href="<?php echo e(route('relatedfile.show', ['patient' => $patient])); ?>"><button type="button" class="btn btn-success"><i class="fa fa-envelope"></i> View Files </button></a>
                            </td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
					<tfoot>
						<tr>
							<th>Clinic Card Number</th>
							<th>Patient Full Name</th>
                            <th>Create File</th>
                            <th>View Files</th>
						</tr>
					</tfoot>
				  </table>
				</div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->       
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->

	<?php $__env->startPush('scripts'); ?>
		<!-- jQuery UI 1.11.4 -->
		<script src="<?php echo e(asset('assets/vendor_components/jquery-ui/jquery-ui.js')); ?>"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.19/js/jquery.dataTables.min.js"></script>
		<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
		<script>
	  	$.widget.bridge('uibutton', $.ui.button);
		  var del = document.getElementById('del');
		  del.addEventListener('click', function(e) {
		  	alert(del.value);
		  });
		</script>
	<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>