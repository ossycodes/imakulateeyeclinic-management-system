<footer class="main-footer">
    &copy; <?php echo date('Y') ?> <a href="#">Imakulateeyeclinic</a>. All Rights Reserved.
</footer>